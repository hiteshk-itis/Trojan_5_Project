import styled from 'styled-components';



export const MainWrapper = styled.div`
height: 100vh;
width: 100%;
background: #ffffff;
padding: 1rem;

`
export const Header = styled.div`
width: 100%;
font-size: 3rem;
font-weight: 300;


`