
import Button from '@mui/material/Button';
import IconButton from '@mui/material/IconButton';
import PhotoCameraIcon from '@mui/icons-material/PhotoCamera'
import './App.css';
import { Header, MainWrapper } from './header';

function App() {
  return (

    <MainWrapper>
      <Header>Trojan 5 Project </Header>
      <div className='mid-bar'></div>
      <Button variant="contained" component="label">
        Upload
        <input hidden accept="image/*" multiple type="file" />
      </Button>
      <IconButton color="primary" aria-label="upload picture" component="label">
        <input hidden accept="image/*" type="file" />
        <PhotoCameraIcon />
      </IconButton>

    </MainWrapper>
  );
}

export default App;
